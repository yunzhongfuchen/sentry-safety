# Sentry UI Redesign Brief

> 生成时间：2026-06-29  
> 分支：`ui/hud-redesign-2026-06-29`  
> 范围：重新设计前端监控 / 记录 / 设置三个页面

---

## 一、项目背景

当前项目 `sentry-safety` 存在两个监控入口：

- `/multi` → `frontend/safety_detection/multi.html`（传统多摄像头控制台）
- `/hud` → `frontend/safety_detection/hud.html`（科幻 HUD 风格监控中心）

本次 redesign 目标是统一监控入口，并采用全新的**毛玻璃粘土风格（Glassmorphism + Claymorphism）**。

---

## 二、已确认需求

### 页面范围

| 页面 | 文件 | 说明 |
|------|------|------|
| 监控页 | `monitor.html` | 新增 `/monitor` 入口，替代 `/multi` 和 `/hud` |
| 记录页 | `records.html` | 替换现有记录页 |
| 设置页 | `settings.html` | 替换现有设置页 |

后端处理：
- 新增 `/monitor` 路由
- `/multi` 和 `/hud` 路由返回 `monitor.html` 内容（兼容旧入口）

### 监控页（Monitor）

- 布局：**顶部状态栏 + 中央主画面 + 右侧摄像头列表 + 底部告警条**
- 仅主画面实时推流（`/cameras/{id}/stream`）
- 右侧摄像头列表只显示：名称 + 在线状态（不推流，节约资源）
- 底部告警列表显示最近告警信息
- URL 同步当前选中摄像头：`/monitor?camera=xxx`

### 记录页（Records）

- 记录列表
- 筛选功能（日期 / 摄像头 / 检测类型）
- 统计概览（今日告警数、各类型分布）

### 设置页（Settings）

- 合并为 3 个 Tab：
  1. 摄像头
  2. 检测配置
  3. 系统设置

### 公共设计系统

- 创建 `frontend/safety_detection/styles/glass-clay.css`
- 三个页面统一引用该 CSS

---

## 三、视觉设计系统

### 设计理念

**"工业实验室精确感 + 温暖粘土材质"**

避免模板化的"奶油色 + 亮琥珀"默认风格，采用更克制的冷灰白背景与焦橙主色，让监控系统既专业又不过于冰冷。

### 颜色系统

```css
:root {
    --bg-base: #f0f2ee;           /* 冷灰白，实验室工作台感 */
    --bg-soft: #f7f8f6;           /* 抬升表面 */
    --bg-elevated: #ffffff;

    --glass-bg: rgba(255, 255, 255, 0.78);
    --glass-border: rgba(255, 255, 255, 0.9);
    --glass-edge: rgba(15, 23, 42, 0.06);
    --glass-shadow:
        0 2px 4px rgba(15, 23, 42, 0.04),
        0 12px 24px rgba(15, 23, 42, 0.06),
        inset 0 1px 0 rgba(255, 255, 255, 0.95);

    --clay-shadow:
        4px 4px 10px rgba(181, 189, 177, 0.5),
        -4px -4px 10px rgba(255, 255, 255, 0.85);
    --clay-shadow-inset:
        inset 3px 3px 6px rgba(181, 189, 177, 0.45),
        inset -3px -3px 6px rgba(255, 255, 255, 0.9);
    --clay-shadow-pressed:
        inset 4px 4px 8px rgba(181, 189, 177, 0.5),
        inset -4px -4px 8px rgba(255, 255, 255, 0.85);

    --text-primary: #1a211c;
    --text-secondary: #5f6b63;
    --text-muted: #949f96;

    --accent: #e05a18;            /* 焦橙色 */
    --accent-soft: rgba(224, 90, 24, 0.10);
    --accent-hover: #c44c12;

    --success: #0d9f6e;
    --warning: #e05a18;
    --danger: #dc2626;
    --info: #2563eb;
}
```

### 字体

- 标题/显示：`Space Grotesk`
- 正文：`Noto Sans SC`
- 数据/时间/代码：`JetBrains Mono`

### 圆角

- 大卡片：`18px`
- 按钮/输入框：`10px`
- 标签/徽章：`6px`

### 公共组件

| 类名 | 用途 |
|------|------|
| `.glass-card` | 毛玻璃卡片 |
| `.clay-button` | 粘土按钮（带按压效果） |
| `.clay-input` | 粘土输入框 |
| `.status-dot` | 在线/离线/告警状态点 |
| `.type-badge` | 检测类型标签 |
| `.nav-header` | 统一顶部导航 |

### 动效

- 卡片 hover：轻微上浮 + 阴影加深
- 按钮：按下时 inset 阴影
- 告警状态点：柔和脉冲动画
- 支持 `prefers-reduced-motion`

---

## 四、页面设计

### 1. 监控页（Monitor）

```
┌─────────────────────────────────────────────────────────┐
│  SENTRY          在线 3 / 5    告警 12    14:32:08 UTC  │  ← 顶部状态栏
├────────────────────────────────────┬────────────────────┤
│                                    │  [● Camera 1]      │
│                                    │  [○ Camera 2]      │
│         主画面 MJPEG               │  [● Camera 3]      │  ← 右侧摄像头列表
│                                    │  [○ Camera 4]      │
│                                    │  [● Camera 5]      │
├────────────────────────────────────┴────────────────────┤
│  [14:32:01] Camera 1 · 明火 (P0)                        │  ← 底部告警条
│  [14:31:45] Camera 3 · 睡岗 (P1)                        │
└─────────────────────────────────────────────────────────┘
```

关键行为：
- 点击右侧摄像头 → 主画面切换，URL 更新
- 切换时只拉取新选中摄像头的 `/cameras/{id}/stream`
- 默认选中第一个在线摄像头

### 2. 记录页（Records）

```
┌─────────────────────────────────────────────────────────┐
│  SENTRY  ·  检测记录                                      │
├─────────────────────────────────────────────────────────┤
│  [今日告警 12]  [火情 5]  [睡岗 3]  [吸烟 2]  [其他 2]   │  ← 统计概览
├─────────────────────────────────────────────────────────┤
│  筛选：日期 [____]  摄像头 [全部 ▼]  类型 [全部 ▼]       │
├─────────────────────────────────────────────────────────┤
│  时间          摄像头      类型      级别    置信度      │
│  14:32:01      Camera 1   明火      P0      96%         │
│  14:31:45      Camera 3   睡岗      P1      82%         │
└─────────────────────────────────────────────────────────┘
```

### 3. 设置页（Settings）

```
┌─────────────────────────────────────────────────────────┐
│  SENTRY  ·  系统设置                                      │
├─────────────────────────────────────────────────────────┤
│  [ 摄像头 ]  [ 检测配置 ]  [ 系统设置 ]                   │  ← 3 Tab
├─────────────────────────────────────────────────────────┤
│                                                         │
│  Tab 内容区（表格 / 表单 / 开关）                        │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

Tab 内容：
- **摄像头**：摄像头列表、添加/编辑/删除/启用禁用
- **检测配置**：检测类型开关、阈值、VLM 相关参数
- **系统设置**：存储清理、日志、重启等系统操作

---

## 五、后端改动要点

1. 新增 `/monitor` 路由，返回 `frontend/safety_detection/monitor.html`
2. `/multi` 和 `/hud` 路由改为返回 `monitor.html` 或 301 重定向到 `/monitor`
3. 确认 `/static/styles/glass-clay.css` 能正确 serve
4. 现有 API 复用：
   - `GET /cameras`：摄像头列表
   - `GET /cameras/{id}/stream`：单路视频流
   - `GET /status`：系统状态 + 最近记录
   - `GET /overlay` / `POST /overlay`：叠加类型配置
   - `GET /records`：历史记录（带分页/筛选参数）

---

## 六、Demo 文件

- `frontend/safety_detection/demo-glass-clay.html`
- 启动本地服务器查看：
  ```bash
  cd frontend/safety_detection
  python3 -m http.server 8765 --bind 127.0.0.1
  # 浏览器打开 http://127.0.0.1:8765/demo-glass-clay.html
  ```

---

## 七、待确认 / 下一步

1. 视觉方向（demo）是否通过？
2. 是否需要调整主色、背景色或字体？
3. 监控页告警条是否需要更强烈的视觉提示？
4. 三个页面的具体字段和交互细节是否需要进一步细化？
5. 后续进入 `superpowers:writing-plans` 制定详细实现计划

---

## 八、相关文件

- `frontend/safety_detection/multi.html`
- `frontend/safety_detection/hud.html`
- `frontend/safety_detection/records.html`
- `frontend/safety_detection/settings.html`
- `frontend/safety_detection/demo-glass-clay.html`
- `backend/main_multi.py`
- `docs/superpowers/plans/2026-05-20-sentry-monitor-hud-redesign.md`
