#!/usr/bin/env python3
"""计算工作日志所需的目录和文件路径。

输出 shell 变量格式，可直接 eval 或 source 使用：
    eval $(python3 get_worklog_paths.py)
"""

import datetime
import os
import platform
import sys


def is_wsl() -> bool:
    if platform.system() != "Linux":
        return False

    if os.environ.get("WSL_DISTRO_NAME") or os.environ.get("WSL_INTEROP"):
        return True

    release = platform.release().lower()
    if "microsoft" in release or "wsl" in release:
        return True

    try:
        with open("/proc/version", "r", encoding="utf-8") as f:
            version = f.read().lower()
        return "microsoft" in version or "wsl" in version
    except OSError:
        return False


def get_default_base_dir() -> str | None:
    system = platform.system()

    if system == "Windows":
        return r"C:\Users\12800\Desktop\Worklog"

    if is_wsl():
        return "/mnt/c/Users/12800/Desktop/Worklog"

    return None


def main():
    # 默认基础目录策略：
    # - Windows: C:/Users/12800/Desktop/Worklog
    # - WSL: /mnt/c/Users/12800/Desktop/Worklog
    # - 普通 Linux: 不猜测默认值，要求通过 WORKLOG_BASE_DIR 显式指定
    default_base = get_default_base_dir()

    base_dir = os.environ.get("WORKLOG_BASE_DIR")
    if not base_dir:
        if default_base is None:
            print(
                "错误：当前环境不是 Windows 或 WSL，且未设置 WORKLOG_BASE_DIR，无法确定工作日志输出目录",
                file=sys.stderr,
            )
            sys.exit(1)
        base_dir = default_base

    # 支持传入日期参数用于测试，格式 YYYY-MM-DD，默认今天
    date_str = sys.argv[1] if len(sys.argv) > 1 else None
    if date_str:
        try:
            today = datetime.datetime.strptime(date_str, "%Y-%m-%d").date()
        except ValueError:
            print(f"错误：日期格式无效 '{date_str}'，请使用 YYYY-MM-DD 格式", file=sys.stderr)
            sys.exit(1)
    else:
        today = datetime.date.today()

    weekday = today.weekday()  # 0=周一
    monday = today - datetime.timedelta(days=weekday)
    sunday = monday + datetime.timedelta(days=6)

    # 周文件夹名：2026-week0601-0607
    week_dir = monday.strftime("%Y-week%m%d-") + sunday.strftime("%m%d")

    # 当天文件名
    draft = today.strftime(".draft-%Y-%m-%d.md")
    daily = today.strftime("%Y-%m-%d-daily.md")
    weekly = week_dir + ".md"

    # 完整路径
    full_week_dir = os.path.join(base_dir, week_dir)
    draft_path = os.path.join(full_week_dir, draft)
    daily_path = os.path.join(full_week_dir, daily)
    weekly_path = os.path.join(full_week_dir, weekly)

    # 输出 shell 变量格式（路径统一使用正斜杠，避免 shell eval 时反斜杠转义问题）
    def _fmt(path: str) -> str:
        return path.replace("\\", "/")

    print(f"WORKLOG_BASE_DIR={_fmt(base_dir)}")
    print(f"WORKLOG_TODAY={today.strftime('%Y-%m-%d')}")
    print(f"WORKLOG_WEEK_START={monday.strftime('%Y-%m-%d')}")
    print(f"WORKLOG_WEEK_END={sunday.strftime('%Y-%m-%d')}")
    print(f"WORKLOG_WEEK_DIR={week_dir}")
    print(f"WORKLOG_DRAFT={draft}")
    print(f"WORKLOG_DAILY={daily}")
    print(f"WORKLOG_WEEKLY={weekly}")
    print(f"WORKLOG_FULL_WEEK_DIR={_fmt(full_week_dir)}")
    print(f"WORKLOG_DRAFT_PATH={_fmt(draft_path)}")
    print(f"WORKLOG_DAILY_PATH={_fmt(daily_path)}")
    print(f"WORKLOG_WEEKLY_PATH={_fmt(weekly_path)}")


if __name__ == "__main__":
    main()
